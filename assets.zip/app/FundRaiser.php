<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FundRaiser extends Model
{
    //
}
